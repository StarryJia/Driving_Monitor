.. cmake-module:: ../../Modules/CMakePackageConfigHelpers.cmake
